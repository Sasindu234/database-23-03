﻿console.log("script.js loaded");

// Function to fetch and display books
function fetchBooks() {
    const booksTableBody = document.getElementById('booksTableBody');
    if (!booksTableBody) return;

    fetch('http://localhost/library_management/backend/fetch_books.php')
        .then(response => response.json())
        .then(books => {
            booksTableBody.innerHTML = ''; // Clear table
            if (Array.isArray(books) && books.length > 0) {
                books.forEach(book => {
                    const row = document.createElement('tr');
                    row.innerHTML = `
                        <td>${book.book_id}</td>
                        <td>${book.title}</td>
                        <td>${book.author}</td>
                        <td>${book.isbn}</td>
                        <td>${book.genre}</td>
                        <td>${book.publication_year}</td>
                        <td>${book.availability ? 'Available' : 'Not Available'}</td>
                        <td><button onclick="deleteBook(${book.book_id})">Delete</button></td>
                    `;
                    booksTableBody.appendChild(row);
                });
            } else {
                booksTableBody.innerHTML = '<tr><td colspan="8">No books available.</td></tr>';
            }
        })
        .catch(error => console.error('Error fetching books:', error));
}

// Function to delete a book
function deleteBook(bookId) {
    if (confirm('Are you sure you want to delete this book?')) {
        fetch(`http://localhost/library_management/backend/delete_book.php?id=${bookId}`, {
            method: 'DELETE'
        })
            .then(response => response.json())
            .then(data => {
                const messageDiv = document.getElementById('message');
                if (messageDiv) {
                    messageDiv.textContent = data.message || data.error;
                    messageDiv.style.color = data.error ? 'red' : 'green';
                }
                fetchBooks(); // Refresh books
            })
            .catch(error => console.error('Error deleting book:', error));
    }
}

// Fetch Customers
const customersTableBody = document.getElementById('customersTableBody');
if (customersTableBody) {
    function fetchCustomers() {
        fetch('http://localhost/library_management/backend/fetch_customers.php')
            .then(response => response.json())
            .then(customers => {
                customersTableBody.innerHTML = '';
                if (Array.isArray(customers) && customers.length > 0) {
                    customers.forEach(customer => {
                        const row = `<tr>
                                    <td>${customer.customer_id}</td>
                                    <td>${customer.name}</td>
                                    <td>${customer.user_id}</td>
                                    <td>${customer.phone_number}</td>
                                    <td>${customer.late_fees}</td>
                                    <td>${customer.books_rented_out}</td>
                                    <td><button onclick="deleteCustomer(${customer.customer_id})">Delete</button></td>
                                </tr>`;
                        customersTableBody.innerHTML += row;
                    });
                } else {
                    customersTableBody.innerHTML = '<tr><td colspan="7">No customers available.</td></tr>';
                }
            })
            .catch(error => console.error('Error fetching customers:', error));
    }
    fetchCustomers();
}

//Function for delete customers
function deleteCustomer(customerId) {
    if (confirm('Are you sure you want to delete this customer?')) {
        fetch(`http://localhost/library_management/backend/delete_customer.php?id=${customerId}`, {
            method: 'DELETE'
        })
            .then(response => response.json())
            .then(data => {
                const messageDiv = document.getElementById('message');
                if (messageDiv) {
                    messageDiv.textContent = data.message || data.error;
                    messageDiv.style.color = data.error ? 'red' : 'green';
                }
                fetchCustomers(); // Refresh customers
            })
            .catch(error => console.error('Error deleting customer:', error));
    }
}

// Fetch Librarians
const librariansTableBody = document.getElementById('librariansTableBody');
if (librariansTableBody) {
    function fetchLibrarians() {
        fetch('http://localhost/library_management/backend/fetch_librarian.php') //Corrected file name
            .then(response => response.json())
            .then(data => {
                librariansTableBody.innerHTML = '';
                if (Array.isArray(data)) {
                    data.forEach(librarian => {
                        let row = `<tr>
                                    <td>${librarian.librarian_id}</td>
                                    <td>${librarian.name}</td>
                                    <td>${librarian.librarian_id}</td>
                                    <td>${librarian.telephone}</td>
                                    <td>${librarian.email}</td>
                                    <td><button onclick="deleteLibrarian(${librarian.librarian_id})">Delete</button></td>
                                </tr>`;
                        librariansTableBody.innerHTML += row;
                    });
                } else {
                    librariansTableBody.innerHTML = '<tr><td colspan="4">No librarians available.</td></tr>';
                }
            })
            .catch(error => console.error('Error fetching librarians:', error));
    }
    fetchLibrarians();
}

function deleteLibrarian(librarianId) {
    if (confirm('Are you sure you want to delete this Librarian?')) {
        fetch(`http://localhost/library_management/backend/delete_librarian.php?id=${librarianId}`, { //Corrected file name
            method: 'DELETE'
        })
            .then(response => response.json())
            .then(data => {
                const librarianMessageDiv = document.getElementById('librarianMessage'); //Using correct message div.
                if (librarianMessageDiv) {
                    librarianMessageDiv.textContent = data.message || data.error;
                    librarianMessageDiv.style.color = data.error ? 'red' : 'green';
                }
                fetchLibrarians(); // Refresh librarians
            })
            .catch(error => console.error('Error deleting Librarian:', error));
    }
}

document.addEventListener('DOMContentLoaded', function () {
    fetchBooks(); // Fetch books when page loads

    // Handle Add Book Form
    const addBookForm = document.getElementById('addBookForm');
    if (addBookForm) {
        addBookForm.addEventListener('submit', function (e) {
            e.preventDefault();
            const formData = new FormData(addBookForm);

            fetch('http://localhost/library_management/backend/add_book.php', {
                method: 'POST',
                body: formData
            })
                .then(response => response.json())
                .then(data => {
                    const messageDiv = document.getElementById('message');
                    if (messageDiv) {
                        messageDiv.textContent = data.message || data.error;
                        messageDiv.style.color = data.error ? 'red' : 'green';
                    }
                    fetchBooks(); // Refresh books
                    addBookForm.reset();
                })
                .catch(error => console.error('Error adding book:', error));
        });
    }

    // Handle Add Librarian Form
    const addLibrarianForm = document.getElementById('addLibrarianForm');
    if (addLibrarianForm) {
        addLibrarianForm.addEventListener('submit', function (e) {
            e.preventDefault();
            const formData = new FormData(addLibrarianForm);

            fetch('http://localhost/library_management/backend/add_librarians.php', { //Corrected file name
                method: 'POST',
                body: formData
            })
                .then(response => response.json())
                .then(data => {
                    const librarianMessageDiv = document.getElementById('librarianMessage');
                    if (librarianMessageDiv) {
                        librarianMessageDiv.textContent = data.message || data.error;
                        librarianMessageDiv.style.color = data.error ? 'red' : 'green';
                    }
                    fetchLibrarians(); // Refresh librarians
                    addLibrarianForm.reset();
                })
                .catch(error => console.error('Error adding librarian:', error));
        });
    }
});