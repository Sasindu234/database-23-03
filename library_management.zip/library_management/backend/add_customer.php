<?php
// CORS headers
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: POST, GET, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type");

include 'db_connect.php';

$response = [];

// Ensure the request method is POST
if ($_SERVER["REQUEST_METHOD"] === "POST") {
    // Capture form data safely
    $name = $_POST['name'] ?? '';
    $user_id = $_POST['user_id'] ?? '';
    $phone_number = $_POST['phone_number'] ?? '';
    $late_fees = $_POST['late_fees'] ?? 0;
    $books_rented_out = $_POST['books_rented_out'] ?? 0;

    // Prepare an SQL statement to prevent SQL injection
    $stmt = $conn->prepare("INSERT INTO customer (name, user_id, phone_number, late_fees, books_rented_out) VALUES (?, ?, ?, ?, ?)");
    $stmt->bind_param("sssii", $name, $user_id, $phone_number, $late_fees, $books_rented_out);

    if ($stmt->execute()) {
        $response['message'] = "Customer added successfully";
    } else {
        $response['error'] = "Error: " . $stmt->error;
    }

    $stmt->close();
} else {
    $response['error'] = "Invalid request method";
}

$conn->close();

// Return the response as JSON
echo json_encode($response);
?>
