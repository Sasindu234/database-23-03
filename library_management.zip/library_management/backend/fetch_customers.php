<?php
// Enable error reporting for debugging
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Allow access from any origin (replace '*' with your domain for production)
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: GET, POST, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type, Authorization");
header('Content-Type: application/json');

include 'db_connect.php';

try {
    if ($conn->connect_error) {
        throw new Exception("Database connection failed: " . $conn->connect_error);
    }

    $sql = "SELECT * FROM customer";
    $result = $conn->query($sql);

    if ($result) {
        if ($result->num_rows > 0) {
            $customer = [];
            while ($row = $result->fetch_assoc()) {
                $customer[] = $row;
            }
            echo json_encode($customer);
        } else {
            echo json_encode(["message" => "No customer found."]);
        }
    } else {
         throw new Exception("Query failed: " . $conn->error);
    }

    $conn->close();

} catch (Exception $e) {
    error_log("Error in fetch_customers.php: " . $e->getMessage()); // Log the error
    echo json_encode(["error" => "An error occurred."]); // Send a generic error response
}
?>