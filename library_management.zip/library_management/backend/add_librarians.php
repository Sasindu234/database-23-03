<?php
// Allow cross-origin requests
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: POST, GET, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type");
header("Content-Type: application/json");

// Include the database connection
include 'db_connect.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Capture form data from the POST request
    $name = $_POST['name'] ?? '';
    $telephone = $_POST['telephone'] ?? '';
    $email = $_POST['email'] ?? '';

    // Validate the input data
    if (empty($name)) {
        echo json_encode(['error' => 'Name is required.']);
        exit;
    }

    // Insert the data into the `librarian` table (without librarian_id)
    $stmt = $conn->prepare("INSERT INTO librarian (name, telephone, email) VALUES (?, ?, ?)");
    $stmt->bind_param("sss", $name, $telephone, $email);

    if ($stmt->execute()) {
        echo json_encode(['message' => 'Librarian added successfully']);
    } else {
        error_log("Error adding librarian: " . $stmt->error);
        echo json_encode(['error' => 'Error: ' . $stmt->error]);
    }

    $stmt->close();
} else {
    echo json_encode(['error' => 'Invalid request method. Please use POST.']);
}

$conn->close();
?>