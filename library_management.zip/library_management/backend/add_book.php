<?php
// Allow cross-origin requests
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: POST, GET, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type");

// Set the correct content-type for the response
header("Content-Type: application/json");

// Include the database connection
include 'db_connect.php';

// Check if the request method is POST
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Capture form data from the POST request
    $title = $_POST['title'] ?? '';
    $author = $_POST['author'] ?? '';
    $isbn = $_POST['isbn'] ?? '';
    $genre = $_POST['genre'] ?? '';
    $publication_year = $_POST['publication_year'] ?? '';
    $availability = $_POST['availability'] ?? 0; // Default to 0 if not set

    // Validate the input data
    if (empty($title) || empty($author) || empty($isbn)) {
        echo json_encode(['error' => 'Title, Author, and ISBN are required.']);
        exit;
    }

    // Insert the data into the `books` table
    $stmt = $conn->prepare("INSERT INTO books (title, author, isbn, genre, publication_year, availability) 
            VALUES (?, ?, ?, ?, ?, ?)");
    $stmt->bind_param("ssssii", $title, $author, $isbn, $genre, $publication_year, $availability);

    if ($stmt->execute()) {
        // If the query was successful, send a JSON response with a success message
        echo json_encode(['message' => 'Book added successfully']);
    } else {
        // If there was an error, send a JSON response with the error message
        echo json_encode(['error' => 'Error: ' . $stmt->error]);
    }

    $stmt->close();
} else {
    // If the request method is not POST, return an error message
    echo json_encode(['error' => 'Invalid request method. Please use POST.']);
}

// Close the database connection
$conn->close();
?>
