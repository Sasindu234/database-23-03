﻿<?php
// Allow access from any origin (replace '*' with your domain for production)
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: GET, POST, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type, Authorization");
header('Content-Type: application/json');

include 'db_connect.php';

try {
    if ($conn->connect_error) {
        throw new Exception("Database connection failed: " . $conn->connect_error);
    }

    $sql = "SELECT * FROM librarian"; // Corrected table name
    $result = $conn->query($sql);

    if ($result) {
        if ($result->num_rows > 0) {
            $librarians = [];
            while ($row = $result->fetch_assoc()) {
                $librarians[] = $row;
            }
            echo json_encode($librarians);
        } else {
            echo json_encode(["message" => "No librarians found."]);
        }
    } else {
        throw new Exception("Query failed: " . $conn->error);
    }

    $conn->close();

} catch (Exception $e) {
    error_log("Error in fetch_librarian.php: " . $e->getMessage()); // Log the error
    echo json_encode(["error" => "An error occurred."]); // Send a generic error response
}
?>