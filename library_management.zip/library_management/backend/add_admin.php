<?php
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: POST");
header("Access-Control-Allow-Headers: Content-Type");

include 'db_connect.php';

$name = $_POST['name'];
$user_id = $_POST['user_id'];
$password = password_hash($_POST['password'], PASSWORD_BCRYPT);

$sql = "INSERT INTO admin (name, user_id, password) VALUES ('$name', '$user_id', '$password')";

if ($conn->query($sql) === TRUE) {
    echo "Admin added successfully";
} else {
    echo "Error: " . $conn->error;
}

$conn->close();
?>
