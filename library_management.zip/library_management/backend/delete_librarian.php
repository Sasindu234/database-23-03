<?php
header("Access-Control-Allow-Origin: *"); // Allow all domains or specify one
header("Access-Control-Allow-Methods: DELETE, OPTIONS"); // Allow DELETE and preflight OPTIONS
header("Access-Control-Allow-Headers: Content-Type");
header("Content-Type: application/json");

include 'db_connect.php'; // Moved inside PHP tags

// Handle preflight OPTIONS request
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit;
}

// Get the book ID from request
$id = isset($_REQUEST['id']) ? intval($_REQUEST['id']) : null;

if ($id) {
    $stmt = $conn->prepare("DELETE FROM librarian WHERE librarian_id = ?");
    $stmt->bind_param("i", $id);

    if ($stmt->execute()) {
        echo json_encode(['message' => "Librarian deleted"]);
    } else {
        echo json_encode(['error' => "Failed to delete Librarian: " . $stmt->error]);
    }

    $stmt->close();
} else {
    echo json_encode(['error' => "Invalid or missing ID"]);
}

$conn->close();
?>
